#!/bin/bash
## Test script

# TODO(mebjas): Fix the testing script, it's broken at the moment.
# echo 'Initiating test sequence'
echo 'Testing is broken at the moment, fix WIP'
# mocha-phantomjs -p node_modules/phantomjs/bin/phantomjs -R dot ./test/test.html5-qrcode.html
